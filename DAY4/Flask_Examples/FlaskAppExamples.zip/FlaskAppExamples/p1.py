from flask import Flask,render_template

obj = Flask(__name__)

@obj.route("/")
def f1():
    return render_template('gpage.html')

@obj.route("/about")
def f2():
    return "<h3><font color='green'>AboutUs Page </font></h3>"
@obj.route("/myblog")
def f3():
    s="<h1>this is my blog page</h1>"
    return s

if __name__ == '__main__':
    obj.run(debug=True,port=1234)
