from flask import *

obj = Flask(__name__)

@obj.route("/")
def f1():
    return render_template('gpage.html')

@obj.route("/mylogin",methods=['post','get'])
def f2():
    Prod_name = request.form['n1']
    return f"<h2>Input product name is:{Prod_name}</h2>"

@obj.route("/mydata")
def f3():
    d = {'pid':[101,102,304],'pname':['pA','pB','pC']}
    return jsonify(d)

@obj.route("/productpage")
def f4():
    return render_template('pview.html',pname = 'mobiledevice')
 
if __name__ == '__main__':
    obj.run(debug=True,port=1234)
